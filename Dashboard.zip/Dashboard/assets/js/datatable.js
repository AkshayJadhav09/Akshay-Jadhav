
$(document).click(function() {
  $('#example').DataTable( {
        ajax: {
                url: 'https://akshayjadhav09.github.io/code/table.json',
                dataSrc: ''
                },
        columns: [
            {data: 'bikeNumber'},
            {data: 'location.address'},
            {data: 'userId'},
            {data: 'reportId' },
    
                  ]
              });
})